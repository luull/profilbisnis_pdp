<footer class="footer">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-8 col-12 text-center">
                {{session('qrcode')}}
                <h4 class="fadeIn text-white mt-4"><strong>{{env('APP_NAME')}}</strong></h4>
                <p class="company-about fadeIn text-white mb-0">{{session('data')->tentang_web}}</p>
                <p class="company-about fadeIn text-white">
                    {{ session('data')->alamat }}
                </p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 text-center">
                <div class="footer-social">
                    <ul class="list-unstyled social-icons social-icons-simple">
                        <li><a class="social-icon wow fadeInUp" href="tel:{{ session('data')->hp }}"><i class="fa fa-phone"></i></a></li>
                        <li><a class="social-icon wow fadeInUp" href="https://api.whatsapp.com/send?phone={{ session('data')->wa }}&text={{ session('data')->wa_template->kontak }} {{ env('APP_NAME') }}" target="blank"><i class="fa fa-whatsapp"></i></a></li>
                        <li><a class="social-icon wow fadeInUp" href="mailto:{{ session('data')->email }}"><i class="fa fa-envelope"></i></a></li>

                    </ul>
                </div>
                <!--Text-->
                <p class="company-about fadeIn text-white">&copy; Copyright 2021 All Rights Reserved
                    Powered by <a href="https://{{env('APP_POWERED_BY')}}" class="text-light">{{env('APP_POWERED_BY')}}</a></p>
            </div>
        </div>
    </div>
</footer>